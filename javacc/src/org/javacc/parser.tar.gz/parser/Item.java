package org.javacc.parser;

public class Item {
	public NormalProduction p = new NormalProduction();
	public int offset = 0;
	public int la;
	public boolean isFirst = false;
	public boolean isLast = false;

	public NormalProduction getProduction() {
		return p;
	}
	public void SetProduction(NormalProduction p) {
		this.p = p;
	}

	public int getOffset() {
		return offset;
	}
	public void SetProduction(NormalProduction p) {
		this.p = p;
	}

}
