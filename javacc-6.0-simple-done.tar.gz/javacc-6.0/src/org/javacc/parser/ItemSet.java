package org.javacc.parser;

import java.util.*;

public class ItemSet {
	public int index;
	public List<Item> itemSet = new ArrayList<Item>();
}
